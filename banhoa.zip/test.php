<?php
$text = '<p>Test paragraph.</p><!-- Comment --> <a href="#fragment">Other text</a>';
echo $text;
echo strip_tags($text);
//echo "\n";

// Allow <p> and <a>
//echo strip_tags($text, '<p><a>');
?>