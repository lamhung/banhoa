$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+264566+'&oi='+303+'&ot=1&&url='+window.location, function(json){})    

});