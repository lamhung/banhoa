<?php
class model_loaisp extends MY_Model {
	function __construct() {
		parent::__construct('loaisp');
	}

	
}