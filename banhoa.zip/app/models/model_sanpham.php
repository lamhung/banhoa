<?php
class model_sanpham extends MY_Model {
	function __construct() {
		parent::__construct('sanpham');
	}

	
}