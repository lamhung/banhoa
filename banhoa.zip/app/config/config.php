<?php
	define('BASE_URL', 'http://localhost/banhoa/');
	define('BASE_DIR', '/banhoa/');
	define('HOST', 'localhost');
	define('DB_NAME', 'banhoa');
	define('USER_DB', 'root');
	define('PASS_DB', '');
	define('DEFAULT_CONTROLLER', 'home');
	define('DEFAULT_ACTION', 'index');

	define("APP_PATH", 'app/controllers');
	define("PATH_VIEWS", 'app/views');
	define("PATH_MODELS", 'app/models');
	define("PATH_PAGINATION", 'app/libraries');
	define("PATH_HELPER", 'app/helpers');
	