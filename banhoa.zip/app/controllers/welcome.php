<?php
class welcome extends Controller {
	function index(){
		$this->view('welcome');
	}
}