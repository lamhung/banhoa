<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome</title>
	<style type="text/css">
		#welcome {width: 500px; height: 200px;margin: auto;border: 1px solid #AAA8A7;text-align: center;color:#802B2B;margin-top: 30px;box-shadow: 4px 4px 4px #CFCFCF}
		#welcome h3 {border-bottom: 1px solid #AAA8A7; padding-bottom: 5px;}
		
	</style>
</head>
<body>
	<div id="welcome">
		<h3>Chào mừng đến với framework của tôi</h3>
		<h4>Lâm Hưng</h4>
		<h4>Mail : lamhung3593@gmail.com</h4>
		<h4>Copyright © 2016 develop by lamhung Version 1.0</h4>
	</div>
</body>
</html>
