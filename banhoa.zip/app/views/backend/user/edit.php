<div class="page-title">
  <div class="row">
    <div class="col-md-12">
      <h4><span class="glyphicon glyphicon-log-in">&nbsp;</span>{user_edit}</h4>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <?php require_once('app/views/backend/user/_form.php');?>
  </div>
</div>
