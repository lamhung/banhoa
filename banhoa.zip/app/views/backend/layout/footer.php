</div><!--END WRAPPER-->
</div><!--END container-fluid -->

<div class="text_link">
			<div class="wap_text_link">
				Copyright &copy; 2012 develop by <a href="http://webdep.local/">webdeponline.com</a> Version 1.0
			</div><!--END WAP TEXT LINK-->
		</div><!--END TEXT LINK-->
		
	</div><!--END LAYOUT-->
</body>
</html>