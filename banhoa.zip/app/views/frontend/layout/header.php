
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cửa hàng hoa đẹp</title>
<base href="<?php echo BASE_URL?>"/>
<link href="<?php echo BASE_URL.'assets/frontend/css/templatemo_style.css'?>" rel="stylesheet" type="text/css" />
<script src="<?php echo BASE_URL.'vendor/jquery-3.1.0.min.js'?>" type="text/javascript" charset="utf-8" ></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-84648514-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>
<div id="templatemo_container">
<div id="templatemo_top_panel">
    	<div id="templatemo_language_section">
			<a href="#"><img src="<?php echo BASE_URL?>assets/frontend/img/images/vi.png" title="Tiếng Việt" /></a>
            <a href="#"><img src="<?php echo BASE_URL?>assets/frontend/img/images/en.jpg" title="English" /></a>
        </div>
        <div id="templatemo_shopping_cart">
       	    Shopping Cart <span>(<a href="#">3 items</a>)</span>      
        </div>
  </div>
     
     <div id="templatemo_header">
     	<img src="<?php echo BASE_URL?>assets/frontend/img/images/templatemo_site_header.jpg" alt="Flower Shop" />
     </div>
     
     <div id="templatemo_banner">
     	<a href="#"><img src="<?php echo BASE_URL?>assets/frontend/img/images/templatemo_banner_image.jpg" alt="Flower Shop - Free Web Template" title="Flower Shop - Free Web Template" border="0" /></a>     </div>
     
<div id="templatemo_menu_panel">
        <ul>
            <li><a href="#" class="current">Home</a></li>
            <li><a href="#">Features</a></li>
            <li><a href="#">Gallery</a></li>
            <li><a href="#">Forum</a></li>  
            <li><a href="#">About Us</a></li> 
            <li><a href="#">Contact Us</a></li>                     
        </ul> 
    </div> <!-- end of menu -->
