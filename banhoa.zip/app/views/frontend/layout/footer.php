     <div id="templatemo_footer_panel">
        <div id="footer_left">
            <img src="<?php echo BASE_URL?>assets/frontend/img/images/mastercard.gif" alt="Master Card" /><img src="<?php echo BASE_URL?>assets/frontend/img/images/visa.gif" alt="Visa Card" /><img src="<?php echo BASE_URL?>assets/frontend/img/images/paypal.gif" alt="PayPal" /><img src="<?php echo BASE_URL?>assets/frontend/img/images/verisignsecured.gif" alt="Verisign Secured" />
        </div>
        <div id="footer_right">
            Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_blank">Free CSS Templates</a>
        </div>
        
        <div class="cleaner">&nbsp;</div>
    </div>
</div>
<!--  Free CSS Template | Designed by TemplateMo.com  --> 

<!--<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js'></script>-->
<script type='text/javascript' src='<?php echo BASE_URL;?>assets/frontend/js/logging.js'></script>
</body>
</html>